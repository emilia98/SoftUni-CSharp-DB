﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SalesDatabaseMigrations.Migrations
{
    public partial class SalesAddDateDefault : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
